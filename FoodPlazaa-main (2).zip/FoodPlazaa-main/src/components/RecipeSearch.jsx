import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import RecipeCard from "./RecipeCard";

const RecipeSearch = () => {
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(false);
  const location = useLocation();

  const query = new URLSearchParams(location.search).get("query")?.trim() || "";

  useEffect(() => {
    if (query) {
      getRecipes();
    }
  }, [query]);

  const getRecipes = async () => {
    setLoading(true);
    try {
      let url = "";

      // ✅ Step 1: First try searching by meal name
      url = `https://www.themealdb.com/api/json/v1/1/search.php?s=${encodeURIComponent(
        query
      )}`;

      let res = await fetch(url);
      let data = await res.json();

      // ✅ Step 2: If no result, try searching by ingredient
      if (!data.meals) {
        url = `https://www.themealdb.com/api/json/v1/1/filter.php?i=${encodeURIComponent(
          query
        )}`;
        res = await fetch(url);
        data = await res.json();

        if (data.meals) {
          // fetch details for each meal to get ingredients
          const detailedMeals = await Promise.all(
            data.meals.map(async (meal) => {
              try {
                const detailRes = await fetch(
                  `https://www.themealdb.com/api/json/v1/1/lookup.php?i=${meal.idMeal}`
                );
                const detailData = await detailRes.json();
                return detailData.meals ? detailData.meals[0] : meal;
              } catch (err) {
                console.error("Error fetching details:", err);
                return meal;
              }
            })
          );
          setRecipes(detailedMeals);
        } else {
          setRecipes([]);
        }
      } else {
        setRecipes(data.meals);
      }
    } catch (error) {
      console.error("Error fetching recipes:", error);
      setRecipes([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="recipe-search-page p-8 bg-gray-100 min-h-screen">
      <h2 className="text-3xl font-bold mb-6 text-center">
        Results for "{query}"
      </h2>

      <div className="recipes grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {loading ? (
          <p className="text-center col-span-3 text-gray-600">Loading...</p>
        ) : recipes.length > 0 ? (
          recipes.map((meal) => {
            // Collect ingredients
            const ingredients = [];
            for (let i = 1; i <= 20; i++) {
              const ing = meal[`strIngredient${i}`];
              const measure = meal[`strMeasure${i}`];
              if (ing && ing.trim()) {
                ingredients.push(`${measure} ${ing}`.trim());
              }
            }

            return (
              <RecipeCard
                key={meal.idMeal}
                title={meal.strMeal}
                image={meal.strMealThumb}
                ingredients={ingredients}
              />
            );
          })
        ) : (
          <p className="text-center col-span-3 text-gray-600">
            No recipes found for "{query}"
          </p>
        )}
      </div>
    </div>
  );
};

export default RecipeSearch;
