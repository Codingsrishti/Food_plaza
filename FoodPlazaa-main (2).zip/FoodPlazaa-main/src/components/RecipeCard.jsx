import React from "react";

const RecipeCard = ({ title, image, ingredients = [] }) => {
  return (
    <div className="bg-white rounded-2xl shadow-md p-4 hover:shadow-lg transition">
      <img
        src={image}
        alt={title}
        className="w-full h-48 object-cover rounded-xl mb-4"
      />
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      {ingredients.length > 0 && (
        <>
          <h4 className="font-medium text-gray-700 mb-1">Ingredients:</h4>
          <ul className="text-sm text-gray-600 list-disc pl-5 space-y-1 max-h-40 overflow-y-auto">
            {ingredients.map((ing, index) => (
              <li key={index}>{ing}</li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
};

export default RecipeCard;
